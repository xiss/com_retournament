<?php
defined('_JEXEC') or die('Restricted access');

// импорт библиотеки контроллеров joomla
jimport('joomla.application.component.controller');

/**
 * ReTournament Component Controller
 */
class ReTournamentController extends JController
{
}


