<?php
defined('_JEXEC') or die('Restricted access');
?>
<h1><?php print_r($this->msg); ?></h1>
