<?php
// Права доступа
defined('_JEXEC') or die('Restricted access');

// Загружаем библиотеку joomla.database.table
jimport('joomla.database.table');

/**
 * Класс Hello Table
 */
class ReTournamentTableReTournament extends JTable
{
    function __construct(&$db)
    {
        parent::__construct('#__retournament', 'id', $db);
    }
}